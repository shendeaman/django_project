from django.apps import AppConfig


class ShareAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'share_app'
