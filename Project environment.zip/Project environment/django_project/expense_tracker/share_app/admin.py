from django.contrib import admin
from share_app.models import Group
# Register your models here.
admin.site.register(Group)

'''
Username (leave blank to use 'sheon'): admin
Email address: admin@gmail.com
Password: aDMIN@987
Password (again):
'''
